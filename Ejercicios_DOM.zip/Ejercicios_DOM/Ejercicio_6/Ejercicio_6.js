document.querySelector('.fn-remove-me').remove()

/*if (elementToRemove) {
  elementToRemove.remove(); */
