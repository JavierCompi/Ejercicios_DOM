/* 1.1 Crear una lista ul > li dinámicamente con los países del array countries*/

const countries = ['Japón', 'Nicaragua', 'Suiza', 'Australia', 'Venezuela']
const ul = document.createElement('ul')

countries.forEach((country) => {
  const li = document.createElement('li')
  li.textContent = country
  ul.appendChild(li)
})

document.body.appendChild(ul)

/* 1.2 Elimina el elemento que tenga la clase .fn-remove-me.*/
const elementToRemove = document.querySelector('.fn-remove-me')
elementToRemove.remove() // Eliminamos el elemento seleccionado

/* 1.3 Crear dinámicamente una lista ul > li dentro del div con el atributo data-function="printHere" usando el array cars*/
const cars = ['Mazda 6', 'Ford fiesta', 'Audi A4', 'Toyota corola']
const printHereDiv = document.querySelector('div[data-function="printHere"]')
const carsUl = document.createElement('ul')

cars.forEach((car) => {
  const li = document.createElement('li')
  li.textContent = car
  carsUl.appendChild(li)
})

printHereDiv.appendChild(carsUl) // Añadimos la lista dentro del div seleccionado

/*1.4 Crear dinámicamente una serie de div que contenga un h4 para el título y una img para la imagen*/

const countrie = [
  { title: 'Random title', imgUrl: 'https://picsum.photos/300/200?random=1' },
  { title: 'Random title', imgUrl: 'https://picsum.photos/300/200?random=2' },
  { title: 'Random title', imgUrl: 'https://picsum.photos/300/200?random=3' },
  { title: 'Random title', imgUrl: 'https://picsum.photos/300/200?random=4' },
  { title: 'Random title', imgUrl: 'https://picsum.photos/300/200?random=5' }
]

countrie.forEach((country) => {
  const div = document.createElement('div')
  const h4 = document.createElement('h4')
  const img = document.createElement('img')

  h4.textContent = country.title // Asignar el título
  img.src = country.imgUrl // Asignar la URL de la imagen

  div.appendChild(h4)
  div.appendChild(img)

  document.body.appendChild(div) // Añadir el div al cuerpo del documento
})
