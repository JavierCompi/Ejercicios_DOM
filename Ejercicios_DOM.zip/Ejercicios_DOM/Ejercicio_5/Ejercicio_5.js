const albums = [
  'De Mysteriis Dom Sathanas',
  'Reign of Blood',
  'Ride the Lightning',
  'Painkiller',
  'Iron Fist'
]

// Crear la lista UL
const ul = document.createElement('ul')

// Iterar sobre el array y agregar cada álbum a la lista
albums.forEach((album) => {
  const li = document.createElement('li') // Crear el elemento LI
  li.textContent = album // Asignar el nombre del álbum
  ul.appendChild(li) // Agregar LI a la lista UL
})

// Añadir la lista UL al cuerpo del documento
document.body.appendChild(ul)
