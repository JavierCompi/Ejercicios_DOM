// 1.1 Evento click que imprime en consola la información del evento de click
document.getElementById('btnToClick').addEventListener('click', function(event) {
  console.log('Evento Click:', event);
});

// 1.2 Evento focus que imprime en consola el valor del input con la clase "focus"
document.querySelector('.focus').addEventListener('focus', function() {
  console.log('Valor del input (focus):', this.value);
});

// 1.3 Evento input que imprime en consola el valor del input mientras se escribe
document.querySelector('.value').addEventListener('input', function() {
  console.log('Valor del input (input):', this.value);
});
